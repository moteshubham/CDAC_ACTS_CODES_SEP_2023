package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.entities.Employee;
import com.app.service.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;

	// http://localhost:8080/employees, method=POST
	@PostMapping("/employees")
	public ResponseEntity<?> addNewEmployee(@RequestBody Employee emp) {
		try {
			System.out.println("in add emp " + emp);
			return ResponseEntity.status(HttpStatus.CREATED).body(employeeService.addNewEmployee(emp));

		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	// http://localhost:8080/employees, method=GET
	@GetMapping("/employees")
	public ResponseEntity<?> getAllEmployees() {
		try {
			System.out.println("in get emps ");
			List<Employee> emplist = employeeService.getAllEmployees();
			if (emplist.isEmpty())
				return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
			// employees found
			return ResponseEntity.status(HttpStatus.OK).body(emplist);

		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	// http://localhost:8080/employees/{empid}, method=GET
	@GetMapping("/employees/{empId}")
	public ResponseEntity<?> getEmployeeById(@PathVariable Long empId) {
		try {
			System.out.println("in get emps ");
			Employee employee = employeeService.getEmployeeById(empId);

			// employee by id found
			return ResponseEntity.status(HttpStatus.OK).body(employee);

		} catch (Exception e) {
			System.out.println("in GETbyID catch");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

}
