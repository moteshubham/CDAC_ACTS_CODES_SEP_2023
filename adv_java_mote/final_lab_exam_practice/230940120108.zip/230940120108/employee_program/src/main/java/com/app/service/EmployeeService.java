package com.app.service;

import java.util.List;

import com.app.entities.Employee;

public interface EmployeeService {

	Employee addNewEmployee(Employee emp);

	List<Employee> getAllEmployees();

	Employee getEmployeeById(Long empId);

}
