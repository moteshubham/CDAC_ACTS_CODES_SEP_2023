package com.app.entities;

public enum DifficultyLevel {
	EASY, MEDIUM, HARD
}
