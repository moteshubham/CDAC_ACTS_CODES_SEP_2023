package com.app.enums;

public enum Gender {
	MALE, FEMALE
}
