package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ApiException;
import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dao.EmployeeDao;
import com.app.entities.Employee;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao employeeDao;

	@Override
	public Employee addNewEmployee(Employee emp) {

		try {
			System.out.println("in POST try");
			return employeeDao.save(emp);

		} catch (Exception e) {
			System.out.println("in POST catch");	//Error while resource creation handled
			throw new ApiException("Could not create employee bcoz : \n" + e.getMessage());
		}
	}

	@Override
	public List<Employee> getAllEmployees() {

		List<Employee> empList = employeeDao.findAll();
		return empList;
	}

	@Override
	public Employee getEmployeeById(Long empId) {
		Employee employee = employeeDao.findById(empId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Emp ID!!!"));
		return employee;
	}

}
