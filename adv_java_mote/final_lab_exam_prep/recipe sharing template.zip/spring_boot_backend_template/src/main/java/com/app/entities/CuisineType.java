package com.app.entities;

public enum CuisineType {
	CONTINENTAL, INDIAN, THAI, KOREAN, CHINESE
}
